﻿using System;
namespace Timbr
{
    public class APIKeys
    {
        public APIKeys()
        {
        }

        public static readonly string CosmosEndpointUrl = "https://game-demo.documents.azure.com:443/";
        public static readonly string CosmosAuthKey = "65MJ0KCe3FdeJ2WsHH75GKNFhyIYjcZ72Y9hgRutG85SGxaz02ROYwKFUz8XloKKIBOCSJHfj79zksZa8NVKzA==";
    }
}
