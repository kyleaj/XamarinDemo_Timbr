﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Timber
{
    public class ParksService
    {
        int offset;
        HttpClient httpClient;

        private static readonly string API_KEY = "";
        private const int LIMIT = 5;

        public ParksService()
        {
            offset = 0;
            httpClient = new HttpClient();
        }

        public async Task<List<TreeProfile>> GetProfiles()
        {
            string url = $"https://developer.nps.gov/api/v1/places?limit={LIMIT}&start={offset}&api_key={API_KEY}";
            httpClient.DefaultRequestHeaders.Clear();
            HttpResponseMessage raw_response = await httpClient.GetAsync(url);
            string response = await raw_response.Content.ReadAsStringAsync();
            JObject data = JObject.Parse(response);
            List<TreeProfile> profiles = new List<TreeProfile>();
            foreach (JObject park in data["data"].Children())
            {
                string id = park["id"].ToString();
                string desr = park["listingdescription"].ToString();
                string name = park["title"].ToString();
                string pic = park["listingimage"]["url"].ToString();
                profiles.Add(new TreeProfile()
                {
                    Id = id,
                    Description = desr,
                    Name = name,
                    ProfilePic = pic
                });
            }
            offset += LIMIT;
            return profiles;
        }
    }
}
